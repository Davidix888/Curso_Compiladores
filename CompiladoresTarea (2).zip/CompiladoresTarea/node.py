class NodoAST:
    pass


class NodoFuncion(NodoAST):

    def __init__(self, tipo, nombre, parametros, cuerpo):
        self.tipo = tipo
        self.nombre = nombre
        self.parametros = parametros
        self.cuerpo = cuerpo

    def traducirPascal(self):

        params = ", ".join(p.traducirPascal() for p in self.parametros)

        cuerpo = "\n  ".join(c.traducirPascal() for c in self.cuerpo)

        return f"function {self.nombre[1]}({params}): integer;\nbegin\n  {cuerpo}\nend;"


class NodoParametro(NodoAST):

    def __init__(self, tipo, nombre):
        self.tipo = tipo
        self.nombre = nombre

    def traducirPascal(self):
        return f"{self.nombre[1]}: integer"


class NodoAsignacion(NodoAST):

    def __init__(self, tipo, nombre, expresion):
        self.tipo = tipo
        self.nombre = nombre
        self.expresion = expresion

    def traducirPascal(self):
        return f"{self.nombre[1]} := {self.expresion.traducirPascal()};"


class NodoOperacion(NodoAST):

    def __init__(self, izquierda, operador, derecha):
        self.izquierda = izquierda
        self.operador = operador
        self.derecha = derecha

    def traducirPascal(self):
        return f"{self.izquierda.traducirPascal()} {self.operador[1]} {self.derecha.traducirPascal()}"


class NodoRetorno(NodoAST):

    def __init__(self, expresion):
        self.expresion = expresion

    def traducirPascal(self):
        return f"suma := {self.expresion.traducirPascal()};"


class NodoIdent(NodoAST):

    def __init__(self, nombre):
        self.nombre = nombre

    def traducirPascal(self):
        return self.nombre[1]


class NodoNumero(NodoAST):

    def __init__(self, valor):
        self.valor = valor

    def traducirPascal(self):
        return self.valor[1]


class NodoLlamadaFuncion(NodoAST):

    def __init__(self, nombre_funcion, argumentos):
        self.nombre_funcion = nombre_funcion
        self.argumentos = argumentos

    def traducirPy(self):
        args = ", ".join(a.traducirPy() for a in self.argumentos)
        return f"{self.nombre_funcion}({args})"


class NodoPrint(NodoAST):

    def __init__(self, expresion):
        self.expresion = expresion

    def traducirPascal(self):
        return f"write({self.expresion.traducirPascal()});"


class NodoPrintln(NodoAST):

    def __init__(self, expresion):
        self.expresion = expresion

    def traducirPascal(self):
        return f"writeln({self.expresion.traducirPascal()});"


class NodoIf(NodoAST):

    def __init__(self, condicion, cuerpo_if, cuerpo_else=None):
        self.condicion = condicion
        self.cuerpo_if = cuerpo_if
        self.cuerpo_else = cuerpo_else

    def traducirPascal(self):

        cuerpo_if = "\n  ".join(c.traducirPascal() for c in self.cuerpo_if)

        codigo = f"if {self.condicion.traducirPascal()} then\nbegin\n  {cuerpo_if}\nend"

        if self.cuerpo_else:

            cuerpo_else = "\n  ".join(c.traducirPascal() for c in self.cuerpo_else)

            codigo += f"\nelse\nbegin\n  {cuerpo_else}\nend"

        return codigo


class NodoWhile(NodoAST):

    def __init__(self, condicion, cuerpo):
        self.condicion = condicion
        self.cuerpo = cuerpo

    def traducirPascal(self):

        cuerpo = "\n  ".join(c.traducirPascal() for c in self.cuerpo)

        return f"while {self.condicion.traducirPascal()} do\nbegin\n  {cuerpo}\nend;"

class NodoFor(NodoAST):

    def __init__(self, inicial, condicion, incremento, cuerpo):
        self.inicial = inicial
        self.condicion = condicion
        self.incremento = incremento
        self.cuerpo = cuerpo

    def traducirPascal(self):

        cuerpo = "\n  ".join(c.traducirPascal() for c in self.cuerpo)

        return f"{self.inicial.traducirPascal()}\nwhile {self.condicion.traducirPascal()} do\nbegin\n  {cuerpo}\n  {self.incremento.traducirPascal()}\nend;"
from html import parser
from lexico import *
from sintactico import *
import json


def main():

    # Ejemplo 1
    codigo_fuente = """
    int suma(int a, int b) {
      return a + b;
    }
    """

    # Ejemplo 2
    codigo_fuenteDos = """
    int suma(int a, int b) {
      int c = a + b;
      print(c);
      return c;
    }
    """

    tokens = identificar_tokens(codigo_fuente)
    tokensDos = identificar_tokens(codigo_fuenteDos)

    arbol_ast = None
    arbol_astDos = None

    # Analisis sintactico ejemplo 1
    try:
        print("Iniciando analisis sintactico")
        parser = Parser(tokens)
        arbol_ast = parser.parsear()
        print("Analisis sintactico exitoso")
    except SyntaxError as e:
        print(f"Error sintáctico: {e}")

    # Analisis sintactico ejemplo 2
    try:
        print("Iniciando analisis sintactico")
        parser = Parser(tokensDos)
        arbol_astDos = parser.parsear()
        print("Analisis sintactico exitoso")
    except SyntaxError as e:
        print(f"Error sintáctico: {e}")

    # Mostrar AST
    print(json.dumps(imprimir_ast(arbol_ast), indent=1))

    nodoExp = NodoOperacion(NodoNumero(5), '+', NodoNumero(8))
    print(json.dumps(imprimir_ast(nodoExp), indent=1))

    # Traducción a Pascal
    if arbol_astDos:
        print("\nTraduccion a Pascal:\n")
        print(arbol_astDos.traducirPascal())


main()